package com.pixogram.followservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FollowserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
