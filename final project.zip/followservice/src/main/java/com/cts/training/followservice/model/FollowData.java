package com.cts.training.followservice.model;



import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FollowData {
	
	private Integer userId;
	private Integer followerId;
}
