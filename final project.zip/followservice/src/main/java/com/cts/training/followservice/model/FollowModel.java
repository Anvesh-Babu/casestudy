package com.cts.training.followservice.model;

import java.util.List;

import com.cts.training.followservice.entity.Follow;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FollowModel {
	
	public List<Follow> followlist;
}
