import { SearchedUser } from './searcheduser.model';

export class SearchedUserList{
    userList : Array<SearchedUser>;
}