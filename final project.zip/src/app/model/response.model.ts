export class ResponseData{
    message : String;
    timestamp : number;
    userId : number;
    profilepic:string;
    
}