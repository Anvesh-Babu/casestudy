import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {
  username : string;
  constructor(public auth : UserAuthService) { }

  ngOnInit() {
    let str=this.auth.getUserDetails();
    let pos = str.indexOf('@');

    this.username = str.substring(0,pos);
  }

}

