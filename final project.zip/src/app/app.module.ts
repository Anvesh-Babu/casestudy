import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderPartOneComponent } from './header-user/header-one/header-part-one.component';
import { HeaderPartTwoComponent } from './header-user/header-two/header-part-two.component';
import { LoginComponent } from './authentication/login/login.component';
import { RegisterComponent } from './authentication/register/register.component';
import { SingleMediaComponent } from './media-actions/upload-media/single-media/single-media.component';
import { MultipleMediaComponent } from './media-actions/upload-media/multiple-media/multiple-media.component';
import { GalleryComponent } from './media-actions/view/gallery/gallery.component';
import { SingleImageComponent } from './media-actions/view/single-image/single-image.component';
import { FollowersComponent } from './profile/followers/followers.component';
import{FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule}from'@angular/common/http';
import { ErrorComponent } from './error/error.component';
import { NewsfeedsComponent } from './Account-details/newsfeeds/newsfeeds.component';
import { AccountUpdateComponent } from './Account-details/account-update/account-update.component';
import { BlockedAccountsComponent } from './Account-details/blocked-accounts/blocked-accounts.component';
import { SearchComponent } from './Account-details/search/search.component';
import { HomeComponent } from './home/home.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderPartOneComponent,
    HeaderPartTwoComponent,
    LoginComponent,
    RegisterComponent,
    SingleMediaComponent,
    MultipleMediaComponent,
    GalleryComponent,
    SingleImageComponent,
    FollowersComponent,
    NewsfeedsComponent,
    BlockedAccountsComponent,
    AccountUpdateComponent,
    SearchComponent,
    ErrorComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,ReactiveFormsModule,
    HttpClientModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
