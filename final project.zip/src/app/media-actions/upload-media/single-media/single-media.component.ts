import { Component, OnInit } from '@angular/core';
import{FormGroup, FormControl, FormBuilder, Validators} from'@angular/forms';
import { Router } from '@angular/router';
import { MediaserviceService } from 'src/app/services/mediaservices/mediaservice.service';
@Component({
  selector: 'app-single-media',
  templateUrl: './single-media.component.html',
  styleUrls: ['./single-media.component.css']
})
export class SingleMediaComponent implements OnInit {
   ftitle : string;
  fdesc : string;
  ftags : string;
  file : any;
  myFormGroup : FormGroup;
  selectedFiles: FileList;

  selectedFile : File;
  date: Date;


  public imagePath;
  imgURL: any;
  public message: string;

  currentFileUpload: File;
  // dynamic class containing only one field 
  // anonymous class
  progress: { percentage: number } = { percentage: 0 };


  constructor(formbuilder : FormBuilder,public mservice : MediaserviceService,public router:Router) {

    this.myFormGroup=formbuilder.group({
      
      "title" : new FormControl(""),
      "description" : new FormControl(""),
      "tags" : new FormControl(""),
    });
   
   }
onImageLoad(event){
  this.selectedFiles = event.target.files;
  this.selectedFile = this.selectedFiles.item(0);
  this.preview(this.selectedFiles);
}

   singleUpload(){
    
    this.ftitle = this.myFormGroup.controls['title'].value;
    this.fdesc = this.myFormGroup.controls['description'].value;
    this.ftags = this.myFormGroup.controls['tags'].value;
    this.date = new Date();
    let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
    if (this.selectedFile.type == 'image/png') {
      this.file = `${this.ftitle}${dateString}.png`;
    }
    if (this.selectedFile.type == 'image/jpeg' || this.selectedFile.type == 'image/jpg') {
      this.file = `${this.ftitle}${dateString}.jpeg`;
    }
  
    console.log(this.file+"\n"+this.ftitle+"\n"+this.fdesc+"\n"+this.ftags);
    //let uploadfile = new Media(this.file,this.ftitle,this.fdesc,this.ftags)

    this.mservice.pushFileToStorage(this.selectedFile,this.ftitle,this.fdesc,this.ftags,this.file,this.selectedFile.type).subscribe(
      (responce)=>{this.router.navigate(['/mymedia/'])});

  }

     // gets calles as soon as a file is selected
  selectFile(event) {
    // document.getElementById('file'); ~ event.target
    // event.target : html component on which event has occured
    this.selectedFiles = event.target.files;
    this.preview(this.selectedFiles);
  }

  // list of files selected
  preview(files){
    if (files.length === 0)
      return;

      // loop around to work on all files
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }

    // reads the content of file, so that it can be used for preview
    // without saving it to angular application folder
    var reader = new FileReader();
    this.imagePath = files;
    // reading file contents for preview
    reader.readAsDataURL(files[0]);
    // when images is loaded call the callback function
    reader.onload = (_event) => {
      this.imgURL = reader.result;
    }
  }



  ngOnInit() {
  }

}