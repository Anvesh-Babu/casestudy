package com.cts.training.mediaservice.exceptions;

public class MediaNotFoundException extends RuntimeException {
		public MediaNotFoundException(String message) {
			// TODO Auto-generated constructor stub
			super(message);
		}
}
