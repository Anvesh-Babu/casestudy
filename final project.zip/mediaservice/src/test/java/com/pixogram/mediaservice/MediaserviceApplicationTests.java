package com.pixogram.mediaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
