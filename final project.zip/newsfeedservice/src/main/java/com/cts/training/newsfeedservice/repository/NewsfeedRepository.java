package com.cts.training.newsfeedservice.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.newsfeedservice.entity.NewsFeed;
import com.cts.training.newsfeedservice.model.NewsFeedModel;

@Repository
public interface NewsfeedRepository extends JpaRepository<NewsFeed,Integer>{

	List<NewsFeed> findByUserId(Integer id);
}
