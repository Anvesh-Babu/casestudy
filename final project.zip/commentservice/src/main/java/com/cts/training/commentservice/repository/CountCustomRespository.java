package com.cts.training.commentservice.repository;

import com.cts.training.commentservice.model.CommentsNumberModel;

public interface CountCustomRespository {
	
	CommentsNumberModel findCountById(Integer mediaid);

}
