package com.cts.training.commentservice.model;

import java.time.LocalDateTime;
import java.util.List;

import com.cts.training.commentservice.entity.Comments;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentsDataModel {
	
	private Integer id;
	private Integer mediaId;
	private Integer userId;
	private String comments;
	private LocalDateTime createdOn;
}
