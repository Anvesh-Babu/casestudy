package com.cts.training.userservice.exceptions;

public class UserNotFoundException extends RuntimeException {
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public UserNotFoundException(String message) {
			// TODO Auto-generated constructor stub
			super(message);
		}
}
