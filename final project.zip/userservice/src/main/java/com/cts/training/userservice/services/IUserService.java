package com.cts.training.userservice.services;

import java.util.List;
import java.util.Optional;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.model.SearchedUserModelList;
import com.cts.training.userservice.model.UserRegistrationModel;

public interface IUserService {
	List<User> findAllUsers();
	Optional<User> findUserById(Integer id);
	public void saveuser(UserRegistrationModel userInput);
	boolean updateUser(User user);
	boolean deleteUser(Integer id);
	public SearchedUserModelList searchUsers(String searchString);
}
