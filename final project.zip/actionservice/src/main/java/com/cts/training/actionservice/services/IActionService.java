package com.cts.training.actionservice.services;

import java.util.List;
import java.util.Optional;

import com.cts.training.actionservice.entity.Action;
import com.cts.training.actionservice.model.CountOfActionsModel;

public interface IActionService {
	List<Action> findAllActions();
	Optional<Action> findActionById(Integer id);
	boolean addAction(Action action);
	boolean updateAction(Action action);
	public CountOfActionsModel getLikesByMediaId(Integer id);
}
